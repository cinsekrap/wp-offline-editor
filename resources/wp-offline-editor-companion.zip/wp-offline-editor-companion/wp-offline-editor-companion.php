<?php
/**
 * Plugin Name: WP Offline Editor Companion
 * Description: Exposes ACF field groups and fields via REST API for WP Offline Editor schema discovery, including code-registered field groups.
 * Version: 1.0.0
 * Author: WP Offline Editor
 * License: MIT
 * Requires at least: 6.0
 * Requires PHP: 7.4
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'rest_api_init', function () {

	// GET wpoe/v1/status — unauthenticated, used for namespace detection.
	register_rest_route( 'wpoe/v1', '/status', [
		'methods'             => 'GET',
		'callback'            => function () {
			return [
				'active'  => true,
				'version' => '1.0.0',
				'acf'     => function_exists( 'acf_get_field_groups' ),
			];
		},
		'permission_callback' => '__return_true',
	] );

	// GET wpoe/v1/field-groups — returns all active ACF field groups.
	register_rest_route( 'wpoe/v1', '/field-groups', [
		'methods'             => 'GET',
		'callback'            => function () {
			if ( ! function_exists( 'acf_get_field_groups' ) ) {
				return new WP_Error( 'acf_missing', 'ACF is not active.', [ 'status' => 404 ] );
			}

			$groups = acf_get_field_groups();
			$result = [];

			foreach ( $groups as $group ) {
				if ( empty( $group['active'] ) ) {
					continue;
				}

				$result[] = [
					'id'       => $group['ID'] ?: 0,
					'key'      => $group['key'],
					'title'    => $group['title'],
					'active'   => true,
					'modified' => $group['modified'] ?? 0,
				];
			}

			return $result;
		},
		'permission_callback' => function () {
			return current_user_can( 'edit_posts' );
		},
	] );

	// GET wpoe/v1/field-groups/(?P<key>[\\w]+)/fields — returns fields for a group.
	register_rest_route( 'wpoe/v1', '/field-groups/(?P<key>[\\w]+)/fields', [
		'methods'             => 'GET',
		'callback'            => function ( WP_REST_Request $request ) {
			if ( ! function_exists( 'acf_get_fields' ) ) {
				return new WP_Error( 'acf_missing', 'ACF is not active.', [ 'status' => 404 ] );
			}

			$group_key = $request->get_param( 'key' );

			// acf_get_fields accepts a group key or ID.
			$fields = acf_get_fields( $group_key );

			if ( $fields === false || $fields === null ) {
				return new WP_Error( 'not_found', 'Field group not found.', [ 'status' => 404 ] );
			}

			return wpoe_normalize_fields( $fields );
		},
		'permission_callback' => function () {
			return current_user_can( 'edit_posts' );
		},
	] );
} );

/**
 * Recursively normalize ACF field arrays for JSON output.
 */
function wpoe_normalize_fields( array $fields ): array {
	$result = [];

	foreach ( $fields as $field ) {
		$normalized = [
			'key'      => $field['key'] ?? '',
			'label'    => $field['label'] ?? '',
			'name'     => $field['name'] ?? '',
			'type'     => $field['type'] ?? '',
			'required' => ! empty( $field['required'] ),
		];

		// Repeater / group sub_fields.
		if ( ! empty( $field['sub_fields'] ) ) {
			$normalized['sub_fields'] = wpoe_normalize_fields( $field['sub_fields'] );
		}

		// Flexible content layouts.
		if ( $field['type'] === 'flexible_content' && ! empty( $field['layouts'] ) ) {
			$layouts = is_array( $field['layouts'] ) ? array_values( $field['layouts'] ) : [];
			$normalized['layouts'] = [];

			foreach ( $layouts as $layout ) {
				$layout_entry = [
					'key'   => $layout['key'] ?? '',
					'name'  => $layout['name'] ?? '',
					'label' => $layout['label'] ?? '',
				];

				if ( ! empty( $layout['sub_fields'] ) ) {
					$layout_entry['sub_fields'] = wpoe_normalize_fields( $layout['sub_fields'] );
				}

				$normalized['layouts'][] = $layout_entry;
			}
		}

		// Select / radio / checkbox choices.
		if ( ! empty( $field['choices'] ) ) {
			$normalized['choices'] = $field['choices'];
		}

		$result[] = $normalized;
	}

	return $result;
}
